"""
webapp.py —— MVP 网站后端（FastAPI）。
- 启动时加载 processed/stats.json + 元数据（英雄/装备/符文名字、英雄头像）。
- 提供 API：/api/champions, /api/champion/{id}, /api/augments_global。
- 首页 index.html 用 JS 拉取渲染（主页排行榜 + 英雄详情）。
"""
import json
import os
import urllib.request
import hashlib
import secrets
import time

from pypinyin import lazy_pinyin
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "processed")
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")


def _load(name, default=None):
    p = os.path.join(OUT_DIR, name)
    if os.path.exists(p):
        try:
            with open(p, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return default
    return default


def _dragon_version():
    try:
        with urllib.request.urlopen("https://ddragon.leagueoflegends.com/api/versions.json", timeout=15) as resp:
            return json.loads(resp.read().decode("utf-8"))[0]
    except Exception:
        # 拿不到最新版本时兜底到包含全部英雄（含新英雄）的版本
        return "16.17.1"


STATS = _load("stats.json", {})
CHAMPS = _load("champion_names.json", {})
AUGS = _load("augment_names.json", {})
ITEMS = _load("item_names.json", {})
AUG_ICONS = _load("augment_icons.json", {})  # 符文ID -> CDN图标URL
DRAGON_VER = os.environ.get("DRAGON_VER", _dragon_version())
PATCH_VERSION = os.environ.get("PATCH_VERSION", "16.16")  # 当前LOL补丁版本，用于网站名标注

app = FastAPI(title="海克斯大乱斗 攻略站")
# 静态资源（桌面宠物等）：把图片放进 static/ 即可经 /static/... 访问
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


def _champ_img(cid):
    c = CHAMPS.get(str(cid), {})
    key = c.get("id")  # DDragon 的 id (如 "Ahri")
    if key:
        return "https://ddragon.leagueoflegends.com/cdn/%s/img/champion/%s.png" % (DRAGON_VER, key)
    return ""


@app.get("/", response_class=HTMLResponse)
def home():
    path = os.path.join(STATIC_DIR, "index.html")
    with open(path, encoding="utf-8") as f:
        return f.read().replace("{{PATCH_VER}}", PATCH_VERSION)

@app.get("/api/version")
def api_version():
    return {"game_version": PATCH_VERSION}


@app.get("/api/champions")
def api_champions():
    champs = STATS.get("champions", [])
    detail = STATS.get("champion_detail", {})
    for c in champs:
        c["image"] = _champ_img(c["id"])
        d = detail.get(c["id"], {})
        top3 = (d.get("augments", []) or [])[:3]
        c["best3"] = [{
            "name": AUGS.get(str(a["id"]), {}).get("name", "符文" + str(a["id"])),
            "quality": AUGS.get(str(a["id"]), {}).get("quality", ""),
            "icon": AUG_ICONS.get(str(a["id"]), ""),
        } for a in top3]
    return JSONResponse(champs)


@app.get("/api/champion/{cid}")
def api_champion(cid: str):
    detail = STATS.get("champion_detail", {}).get(cid)
    if not detail:
        return JSONResponse({"error": "no data"}, status_code=404)
    detail = dict(detail)

    # 单个符文：补名字+品质+图标，并按品质分三档（每档最多5个，保留原胜率排序）
    augs_meta = {}
    for a in detail.get("augments", []):
        meta = AUGS.get(str(a["id"]), {})
        a["name"] = meta.get("name", "符文" + str(a["id"]))
        a["quality"] = meta.get("quality", "")
        a["icon"] = AUG_ICONS.get(str(a["id"]), "")
        augs_meta[str(a["id"])] = a["name"]
    by_q = {}
    for a in detail.get("augments", []):
        by_q.setdefault(a.get("quality", "其他"), []).append(a)
    quality_order = ["白银", "黄金", "棱彩", "其他"]
    detail["augments_by_quality"] = [
        {"quality": q, "items": by_q.get(q, [])[:15]} for q in quality_order if by_q.get(q)
    ]

    # 组合：过滤"只有1个符文"的，只保留>=2个，并附上符文名+品质，精简到6条
    combos = []
    for c in detail.get("combos", []):
        augs = c.get("augments", [])
        if len(augs) < 2:
            continue
        c["augment_meta"] = [{
            "id": str(x),
            "name": AUGS.get(str(x), {}).get("name", "符文" + str(x)),
            "quality": AUGS.get(str(x), {}).get("quality", ""),
            "icon": AUG_ICONS.get(str(x), ""),
        } for x in augs]
        combos.append(c)
    detail["combos"] = combos[:20]

    # 协同/出装/对位 附名字+品质+图标 并精简到15条
    for s in detail.get("synergy", []):
        s["aname"] = AUGS.get(str(s["a"]), {}).get("name", str(s["a"]))
        s["bname"] = AUGS.get(str(s["b"]), {}).get("name", str(s["b"]))
        s["aquality"] = AUGS.get(str(s["a"]), {}).get("quality", "")
        s["bquality"] = AUGS.get(str(s["b"]), {}).get("quality", "")
        s["aicon"] = AUG_ICONS.get(str(s["a"]), "")
        s["bicon"] = AUG_ICONS.get(str(s["b"]), "")
    detail["synergy"] = detail.get("synergy", [])[:15]
    # 出装：按物品 id 附上 ddragon 装备图标（与头像同版本）
    for b in detail.get("builds", []):
        b["item_icons"] = ["https://ddragon.leagueoflegends.com/cdn/%s/img/item/%s.png" % (DRAGON_VER, i) for i in b.get("items", [])]
    detail["builds"] = detail.get("builds", [])[:15]
    # 克制推荐：过滤掉"质变/潘朵拉"这类随机事件符文（结果随机、非确定性克制），并补品质，再取前6
    cnt = []
    for s in detail.get("counters", []):
        nm = s.get("augment_name", "")
        if ("质变" in nm) or ("潘朵拉" in nm):
            continue
        s["augment_quality"] = AUGS.get(str(s.get("augment", "")), {}).get("quality", "")
        s["icon"] = AUG_ICONS.get(str(s.get("augment", "")), "")
        cnt.append(s)
    detail["counters"] = cnt[:15]

    detail["image"] = _champ_img(cid)
    return JSONResponse(detail)


@app.get("/api/augments_global")
def api_augments_global():
    return JSONResponse(STATS.get("augments_global", []))


@app.get("/api/augments_all")
def api_augments_all():
    """查看所有符文：按品质分组，组内按中文名拼音排序，附效果描述（去掉问号占位）。"""
    def clean(t):
        return (t or "").replace("？", "").replace("?", "").strip()

    groups = {}
    for aid, meta in AUGS.items():
        q = meta.get("quality") or "其他"
        groups.setdefault(q, []).append({
            "id": aid,
            "name": clean(meta.get("name", "符文" + aid)),
            "en": clean(meta.get("en", "")),
            "desc": clean(meta.get("desc", "")),
            "icon": AUG_ICONS.get(str(aid), ""),
            "quality": q,
            "_sort": "".join(lazy_pinyin(meta.get("name", ""))) or aid,
        })
    order = ["白银", "黄金", "棱彩", "其他"]
    result = []
    for q in order:
        items = groups.get(q, [])
        items.sort(key=lambda x: (x["_sort"], x["id"]))
        for it in items:
            it.pop("_sort", None)
        result.append({"quality": q, "items": items})
    return JSONResponse(result)


# ============ 本地用户登录（演示）============
USERS_PATH = os.path.join(OUT_DIR, "users.json")
try:
    with open(USERS_PATH, encoding="utf-8") as _f:
        USERS = json.load(_f)
except Exception:
    USERS = {}  # id -> {id,name,contact,salt,phash,avatar,tokens,is_admin,created}

# 迁移：给老记录补 tokens 列表（支持同一账号多端会话，登录不互相顶掉）
for _u in USERS.values():
    if not _u.get("tokens"):
        _u["tokens"] = [_u["token"]] if _u.get("token") else []

CODES = {}  # contact -> {code, exp}


def _save_users():
    with open(USERS_PATH, "w", encoding="utf-8") as f:
        json.dump(USERS, f, ensure_ascii=False, indent=2)


def _hash(pw, salt):
    return hashlib.sha256((salt + pw).encode("utf-8")).hexdigest()


def _find_by_contact(c):
    for u in USERS.values():
        if u.get("contact") == c:
            return u
    return None


async def _body(request):
    try:
        return await request.json()
    except Exception:
        return {}


def _auth_user(req):
    h = req.headers.get("authorization", "")
    if h.startswith("Bearer "):
        t = h[7:]
        for u in USERS.values():
            if t in u.get("tokens", []) or t == u.get("token"):
                return u
    return None


def _user_public(u):
    return {"id": u["id"], "name": u.get("name", ""), "contact": u.get("contact", ""),
            "avatar": u.get("avatar", ""), "is_admin": bool(u.get("is_admin"))}


@app.post("/api/auth/send_code")
async def api_send_code(request: Request):
    d = await _body(request)
    contact = (d.get("contact") or "").strip()
    if not contact:
        return JSONResponse({"ok": False, "error": "请输入手机号/邮箱"}, status_code=400)
    code = "%06d" % secrets.randbelow(1000000)
    CODES[contact] = {"code": code, "exp": time.time() + 600}
    # 演示：直接把验证码返回给前端显示（未接短信/邮箱）
    return {"ok": True, "code": code, "demo": True}


@app.post("/api/auth/register")
async def api_register(request: Request):
    d = await _body(request)
    contact = (d.get("contact") or "").strip()
    code = (d.get("code") or "").strip()
    password = d.get("password") or ""
    name = (d.get("name") or "").strip() or ("用户" + contact[-4:])
    c = CODES.get(contact)
    if not c or c["code"] != code or c["exp"] < time.time():
        return JSONResponse({"ok": False, "error": "验证码错误或已过期"}, status_code=400)
    if _find_by_contact(contact):
        return JSONResponse({"ok": False, "error": "该账号已注册，请直接登录"}, status_code=400)
    salt = secrets.token_hex(8)
    uid = secrets.token_hex(8)
    is_admin = len(USERS) == 0  # 第一个注册的用户设为管理员
    token = secrets.token_hex(16)
    USERS[uid] = {"id": uid, "name": name, "contact": contact, "salt": salt,
                  "phash": _hash(password, salt), "avatar": "", "tokens": [token],
                  "is_admin": is_admin, "created": int(time.time())}
    _save_users()
    return {"ok": True, "token": token, "user": _user_public(USERS[uid])}


@app.post("/api/auth/register_pub")
async def api_register_pub(request: Request):
    """公开注册：邮箱/手机号 + 密码（无需验证码，可真正上线用）。"""
    d = await _body(request)
    contact = (d.get("contact") or "").strip()
    password = d.get("password") or ""
    name = (d.get("name") or "").strip() or ("用户" + contact[-4:])
    if not contact or len(password) < 6:
        return JSONResponse({"ok": False, "error": "请填写邮箱/手机号，密码至少6位"}, status_code=400)
    if "@" not in contact:
        return JSONResponse({"ok": False, "error": "请输入有效邮箱"}, status_code=400)
    if _find_by_contact(contact):
        return JSONResponse({"ok": False, "error": "该账号已注册，请直接登录"}, status_code=400)
    salt = secrets.token_hex(8)
    uid = secrets.token_hex(8)
    is_admin = len(USERS) == 0  # 第一个注册的用户设为管理员
    token = secrets.token_hex(16)
    USERS[uid] = {"id": uid, "name": name, "contact": contact, "salt": salt,
                  "phash": _hash(password, salt), "avatar": "", "tokens": [token],
                  "is_admin": is_admin, "created": int(time.time())}
    _save_users()
    return {"ok": True, "token": token, "user": _user_public(USERS[uid])}


@app.post("/api/auth/login")
async def api_login(request: Request):
    d = await _body(request)
    contact = (d.get("contact") or "").strip()
    code = (d.get("code") or "").strip()
    password = d.get("password") or ""
    u = _find_by_contact(contact)
    if not u:
        return JSONResponse({"ok": False, "error": "账号不存在，请先注册"}, status_code=404)
    if code:
        c = CODES.get(contact)
        if not c or c["code"] != code or c["exp"] < time.time():
            return JSONResponse({"ok": False, "error": "验证码错误或已过期"}, status_code=400)
    elif password:
        if u.get("phash") != _hash(password, u.get("salt", "")):
            return JSONResponse({"ok": False, "error": "密码错误"}, status_code=400)
    else:
        return JSONResponse({"ok": False, "error": "请输入验证码或密码"}, status_code=400)
    tok = secrets.token_hex(16)
    u.setdefault("tokens", []).append(tok)
    _save_users()
    return {"ok": True, "token": tok, "user": _user_public(u)}


@app.get("/api/auth/me")
async def api_me(request: Request):
    u = _auth_user(request)
    if not u:
        return JSONResponse({"ok": False, "error": "未登录"}, status_code=401)
    return {"ok": True, "user": _user_public(u)}


@app.post("/api/auth/avatar")
async def api_avatar(request: Request):
    u = _auth_user(request)
    if not u:
        return JSONResponse({"ok": False, "error": "未登录"}, status_code=401)
    d = await _body(request)
    dataurl = d.get("avatar") or ""
    if not dataurl.startswith("data:image"):
        return JSONResponse({"ok": False, "error": "无效图片"}, status_code=400)
    import base64
    header, b64 = dataurl.split(",", 1)
    raw = base64.b64decode(b64)
    ext = "png"
    if "image/jpeg" in header:
        ext = "jpg"
    elif "image/webp" in header:
        ext = "webp"
    avdir = os.path.join(STATIC_DIR, "avatars")
    os.makedirs(avdir, exist_ok=True)
    fname = "%s.%s" % (u["id"], ext)
    with open(os.path.join(avdir, fname), "wb") as f:
        f.write(raw)
    u["avatar"] = "/static/avatars/" + fname
    _save_users()
    return {"ok": True, "avatar": u["avatar"]}


@app.post("/api/auth/logout")
async def api_logout(request: Request):
    u = _auth_user(request)
    if u:
        h = request.headers.get("authorization", "")
        t = h[7:] if h.startswith("Bearer ") else ""
        u["tokens"] = [x for x in u.get("tokens", []) if x != t]
        if u.get("token") == t:
            u["token"] = None
        _save_users()
    return {"ok": True}


@app.post("/api/auth/password")
async def api_password(request: Request):
    u = _auth_user(request)
    if not u:
        return JSONResponse({"ok": False, "error": "未登录"}, status_code=401)
    d = await _body(request)
    pw = d.get("password") or ""
    if len(pw) < 4:
        return JSONResponse({"ok": False, "error": "密码至少4位"}, status_code=400)
    salt = secrets.token_hex(8)
    u["salt"] = salt
    u["phash"] = _hash(pw, salt)
    _save_users()
    return {"ok": True}


@app.post("/api/auth/name")
async def api_name(request: Request):
    u = _auth_user(request)
    if not u:
        return JSONResponse({"ok": False, "error": "未登录"}, status_code=401)
    d = await _body(request)
    name = (d.get("name") or "").strip()
    if not name:
        return JSONResponse({"ok": False, "error": "请输入用户名"}, status_code=400)
    u["name"] = name
    _save_users()
    return {"ok": True, "name": name}


# ============ 用户偏好（存服务器，按账号同步）============
PREF_KEYS = ("bg", "bgImg", "pets", "theme")


@app.get("/api/auth/prefs")
async def api_prefs_get(request: Request):
    u = _auth_user(request)
    if not u:
        return JSONResponse({"ok": False, "error": "未登录"}, status_code=401)
    return {"ok": True, "prefs": {k: u.get(k, "") for k in PREF_KEYS}}


@app.post("/api/auth/prefs")
async def api_prefs_set(request: Request):
    u = _auth_user(request)
    if not u:
        return JSONResponse({"ok": False, "error": "未登录"}, status_code=401)
    d = await _body(request)
    for k in PREF_KEYS:
        if k in d:
            u[k] = d[k]
    _save_users()
    return {"ok": True, "prefs": {k: u.get(k, "") for k in PREF_KEYS}}


# ============ 管理员后台 ============
def _admin_required(req):
    u = _auth_user(req)
    if not u or not u.get("is_admin"):
        return None
    return u


@app.get("/api/admin/users")
async def api_admin_users(request: Request):
    u = _admin_required(request)
    if not u:
        return JSONResponse({"ok": False, "error": "需要管理员权限"}, status_code=403)
    users = [{"id": x["id"], "name": x.get("name"), "contact": x.get("contact"),
              "avatar": x.get("avatar", ""), "is_admin": bool(x.get("is_admin")),
              "created": x.get("created")} for x in USERS.values()]
    users.sort(key=lambda x: -(x["created"] or 0))
    return {"ok": True, "users": users}


@app.post("/api/admin/user/{uid}")
async def api_admin_user(request: Request, uid: str):
    u = _admin_required(request)
    if not u:
        return JSONResponse({"ok": False, "error": "需要管理员权限"}, status_code=403)
    d = await _body(request)
    tgt = USERS.get(uid)
    if not tgt:
        return JSONResponse({"ok": False, "error": "用户不存在"}, status_code=404)
    if "is_admin" in d:
        tgt["is_admin"] = bool(d["is_admin"])
    if d.get("name"):
        tgt["name"] = str(d["name"]).strip() or tgt["name"]
    if d.get("password"):
        salt = secrets.token_hex(8)
        tgt["salt"] = salt
        tgt["phash"] = _hash(d["password"], salt)
    _save_users()
    return {"ok": True}


@app.post("/api/admin/delete/{uid}")
async def api_admin_delete(request: Request, uid: str):
    u = _admin_required(request)
    if not u:
        return JSONResponse({"ok": False, "error": "需要管理员权限"}, status_code=403)
    if uid == u["id"]:
        return {"ok": False, "error": "不能删除自己"}
    USERS.pop(uid, None)
    _save_users()
    return {"ok": True}
